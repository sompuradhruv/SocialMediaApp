package sompura.dhruv.chatterbox

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
